#ifndef __HASHES_H__
#define __HASHES_H__

#define HASH_EXPLORER_EXE		0x095e2844

#endif