#include <Windows.h>
#include <stdio.h>

#include "hook.h"
#include "crt.h"


