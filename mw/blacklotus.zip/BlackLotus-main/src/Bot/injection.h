#ifndef __INJECTION_H__
#define __INJECTION_H__

BOOL InjectBot(DWORD ProcessId, LPTHREAD_START_ROUTINE Thread);

#endif //__INJECTION_H__