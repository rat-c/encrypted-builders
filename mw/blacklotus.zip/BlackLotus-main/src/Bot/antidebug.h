#ifndef __ANTIDEBUG_H__
#define __ANTIDEBUG_H__

#include "nzt.h"

BOOL IsBeingDebuggedAlt();
WINERROR IsBeingDebugged();

#endif //__ANTIDEBUG_H__