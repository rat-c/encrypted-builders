#ifndef __REPORT_H__
#define __REPORT_H__

BOOL StartReportThread(void);

#endif //__REPORT_H__