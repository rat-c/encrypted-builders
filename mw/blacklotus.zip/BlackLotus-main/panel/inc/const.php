<?php
//paths
$CONST_PRIVATE_FOLDER         = 'private/';

//commands
$CONST_COMMAND_DL_EXEC	    = 1;
$CONST_COMMAND_UPDATE		= 2;
$CONST_COMMAND_LOAD_PLUGIN	= 3;
$CONST_COMMAND_KILL		    = 4;
$CONST_COMMAND_UNINSTALL	= 5;

//report type
$CONST_REPORT_TYPE_KNOCK    = '0x001337';
$CONST_REPORT_TYPE_NEW      = '0x001488';

//misc
$CONST_PAGE_LIMIT           = 5;

//gate
$CONST_GATE_KEY             = 'LET_ME_IN!';
?>