<?php
$CONF_TIMEOUT_OFFLINE               = 120;
$CONF_TIMEOUT_DEAD                  = 259200;
$CONF_DB_HOST                       = "127.0.0.1";
$CONF_DB_NAME                       = "panel";
$CONF_DB_USER                       = "root";
$CONF_DB_PASS                       = "";
$CONF_PANEL_USER                    = "yukari";
$CONF_PANEL_PASS                    = "1625cdb75d25d9f699fd2779f44095b6e320767f606f095eb7edab5581e9e3441adbb0d628832f7dc4574a77a382973ce22911b7e4df2a9d2c693826bbd125bc";
?>
